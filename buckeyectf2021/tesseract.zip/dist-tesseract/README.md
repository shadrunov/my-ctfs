docker run -p 8080:8080 --privileged -it cmd_injection
